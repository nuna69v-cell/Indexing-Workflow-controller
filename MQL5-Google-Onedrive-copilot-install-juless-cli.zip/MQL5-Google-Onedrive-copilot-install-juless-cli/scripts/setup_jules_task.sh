#!/bin/bash

# Jules Task Setup Script
# This script helps set up and pull a Jules task

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

TASK_ID="${1:-11566195936388909103}"

echo -e "${GREEN}=== Jules Task Setup ===${NC}"
echo "Task ID: $TASK_ID"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed${NC}"
    echo "Please install Node.js from https://nodejs.org/"
    exit 1
fi

echo -e "${GREEN}✓ Node.js is installed: $(node --version)${NC}"

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm is not installed${NC}"
    exit 1
fi

echo -e "${GREEN}✓ npm is installed: $(npm --version)${NC}"
echo ""

# Check if Jules CLI is installed
if ! command -v jules &> /dev/null; then
    echo -e "${YELLOW}⚠ Jules CLI is not installed${NC}"
    echo "Installing Jules CLI..."
    npm install -g @google/jules
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Jules CLI installed successfully${NC}"
    else
        echo -e "${RED}❌ Failed to install Jules CLI${NC}"
        exit 1
    fi
else
    echo -e "${GREEN}✓ Jules CLI is already installed${NC}"
fi

echo ""

# Check Jules authentication status
echo "Checking Jules authentication..."
if jules remote list --session &> /dev/null; then
    echo -e "${GREEN}✓ Jules is authenticated${NC}"
else
    echo -e "${YELLOW}⚠ Jules is not authenticated${NC}"
    echo "Running 'jules login'..."
    echo "This will open a browser window for Google OAuth authentication."
    echo ""
    
    jules login
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Successfully authenticated with Jules${NC}"
    else
        echo -e "${RED}❌ Authentication failed${NC}"
        exit 1
    fi
fi

echo ""
echo -e "${GREEN}=== Pulling Jules Task ===${NC}"
echo "Task ID: $TASK_ID"
echo ""

# Pull the task
jules remote pull --session "$TASK_ID"

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✓ Task pulled successfully!${NC}"
    echo ""
    echo "Next steps:"
    echo "1. Review the task details and requirements"
    echo "2. Apply any code changes or updates"
    echo "3. Test your changes:"
    echo "   python scripts/ci_validate_repo.py"
    echo "   python scripts/test_automation.py"
    echo "4. Commit and push your changes"
else
    echo ""
    echo -e "${RED}❌ Failed to pull task${NC}"
    echo ""
    echo "Troubleshooting tips:"
    echo "1. Verify the task ID is correct"
    echo "2. Check that you have access to the task"
    echo "3. Ensure your GitHub account is linked in Jules"
    echo "4. Try viewing the task in the Jules web dashboard: https://jules.google/"
    exit 1
fi
