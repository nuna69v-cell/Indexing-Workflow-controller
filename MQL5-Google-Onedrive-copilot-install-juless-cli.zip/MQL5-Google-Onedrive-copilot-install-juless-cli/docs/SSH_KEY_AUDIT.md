# SSH Key Audit Report

**Date**: 2026-02-18  
**Requested by**: @mouy-leng  
**Issue**: Investigation of ECDSA SSH key usage

## SSH Key Details

```
Type: ecdsa-sha2-nistp256
Key: AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBLjxGzOnZXj7/4tvo0PkaMFMYVzr+0lK2ZruE0FH4upnCFo//O140zhutN61/4qiDGD+ESsKTsUJil0q9o72dXQ=
Comment: #ssh.id - @mouy-leng
```

## Investigation Summary

### Repository Search Results

✅ **Key NOT found in repository code**
- Searched all files in the repository
- Checked git history for any commits containing the key
- No references to this specific ECDSA key found

### Current SSH Configuration

The repository currently uses a **different SSH key** as documented in `SSH_SETUP.md`:

```
Type: Ed25519 (more secure than ECDSA)
Key: ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIEeSLWKibLOYIOA794iClIT7WU/32N1BbfzHR8hopSGG
Comment: jules@google.com
```

This Ed25519 key is configured for:
1. GitHub repository access
2. MQL5 Forge (optional)
3. VPS access (optional)

## Possible Locations of the ECDSA Key

Since the key is not in the repository, it may be configured in one of these locations:

### 1. **GitHub Deploy Keys** (Most Likely)
- Deploy keys are configured in repository settings
- Path: `Settings` → `Deploy keys`
- These keys are used by GitHub Actions to push to other repositories
- **Action**: Check https://github.com/A6-9V/MQL5-Google-Onedrive/settings/keys

### 2. **Personal SSH Keys on GitHub**
- User-level SSH keys for @mouy-leng's account
- Path: GitHub profile → `Settings` → `SSH and GPG keys`
- **Action**: Check https://github.com/settings/keys

### 3. **VPS/Server authorized_keys**
- May be configured on a VPS for remote access
- Location on server: `~/.ssh/authorized_keys`
- **Action**: Check VPS if you have one configured

### 4. **GitHub Actions Secrets**
- May be stored as a secret: `SSH_PRIVATE_KEY` or similar
- Path: Repository → `Settings` → `Secrets and variables` → `Actions`
- **Action**: Check https://github.com/A6-9V/MQL5-Google-Onedrive/settings/secrets/actions

### 5. **Third-party Services**
- May be configured in:
  - Railway.app
  - Render.com
  - Google Cloud Platform
  - Fly.io
  - Docker Hub

## Workflows Using SSH

### GitHub Pages Sync Workflow
- **File**: `.github/workflows/github-pages-sync.yml`
- **Method**: Uses HTTPS with `GITHUB_TOKEN` (not SSH)
- **Target**: `Mouy-leng/-LengKundee-mql5.github.io.git`
- **Status**: ✅ Not using the ECDSA key

### OneDrive Sync Workflow
- **File**: `.github/workflows/onedrive-sync.yml`
- **Method**: Uses rclone configuration
- **Status**: ✅ Not using SSH

## Recommendations

### 1. Identify Key Usage
Check the following locations to determine where this key is being used:
```bash
# Check GitHub deploy keys
gh api repos/A6-9V/MQL5-Google-Onedrive/keys

# Check personal SSH keys (requires authentication)
gh api user/keys
```

### 2. Security Best Practices
- **Use Ed25519 instead of ECDSA**: Ed25519 is more secure and efficient
- **Key Rotation**: Regularly rotate SSH keys (every 6-12 months)
- **Remove Unused Keys**: Delete any keys that are no longer needed
- **Use Separate Keys**: Use different keys for different purposes (deploy vs. personal)

### 3. Key Management
If the key is still needed:
- Document its purpose in `SSH_SETUP.md`
- Add it to password manager for backup
- Set calendar reminder for rotation

If the key is not needed:
- Remove it from GitHub deploy keys
- Remove it from personal SSH keys
- Remove it from any VPS authorized_keys
- Remove it from GitHub Actions secrets

### 4. Migration to Ed25519
If this key is still in use, consider migrating to Ed25519:

```bash
# Generate new Ed25519 key
ssh-keygen -t ed25519 -C "your_email@example.com" -f ~/.ssh/id_ed25519_deploy

# Display public key
cat ~/.ssh/id_ed25519_deploy.pub

# Add to GitHub and remove old ECDSA key
```

## Next Steps

1. **Owner Action Required**: @mouy-leng should:
   - Check GitHub repository settings for deploy keys
   - Check personal GitHub SSH keys
   - Check any VPS/server configurations
   - Confirm whether this key is still needed

2. **If Key is Found**:
   - Document its purpose
   - Update `SSH_SETUP.md` with details
   - Consider rotating to Ed25519

3. **If Key is Not Found**:
   - Key may have been removed already
   - No action needed

## References

- [GitHub SSH Key Documentation](https://docs.github.com/en/authentication/connecting-to-github-with-ssh)
- [Ed25519 vs ECDSA](https://security.stackexchange.com/questions/50878/ecdsa-vs-ecdh-vs-ed25519-vs-curve25519)
- Repository SSH Setup: `SSH_SETUP.md`

## Audit Log

| Date | Action | User |
|------|--------|------|
| 2026-02-18 | Initial investigation | GitHub Copilot Agent |
| 2026-02-18 | Key not found in repository | GitHub Copilot Agent |
| 2026-02-18 | Audit document created | GitHub Copilot Agent |

---

**Status**: ⚠️ Awaiting owner verification  
**Priority**: Medium (Security review)
