# Knowledge Base Helper Script

This script provides easy access to the project's NotebookLM notebooks and OneDrive Blueprint resources.

## Usage

```bash
python scripts/knowledge_base_helper.py [command] [resource]
```

## Commands

### List all resources
```bash
python scripts/knowledge_base_helper.py list
```
Displays all available NotebookLM notebooks and OneDrive resources with their URLs and descriptions.

### Get URL for a specific resource
```bash
python scripts/knowledge_base_helper.py url notebooklm_primary
python scripts/knowledge_base_helper.py url notebooklm_blueprint
python scripts/knowledge_base_helper.py url onedrive_blueprint
```

### Open resource in browser
```bash
python scripts/knowledge_base_helper.py open notebooklm_primary
python scripts/knowledge_base_helper.py open notebooklm_blueprint
```

### Display context file
```bash
python scripts/knowledge_base_helper.py context
```
Shows the contents of `docs/NOTEBOOK_LM_CONTEXT.txt` which contains all URLs and AI agent directives.

### Show help
```bash
python scripts/knowledge_base_helper.py help
```

## Available Resources

- **notebooklm_primary** - Primary NotebookLM context (Main repository documentation)
- **notebooklm_blueprint** - Blueprint & Strategy NotebookLM (Trading strategies and EA blueprints)
- **notebooklm_legacy** - Legacy Archive NotebookLM (Historical reference)
- **onedrive_blueprint** - OneDrive Blueprint Notes (Quick reference and visual diagrams)

## Examples

```bash
# List all available resources
python scripts/knowledge_base_helper.py list

# Get the URL for the blueprint notebook
python scripts/knowledge_base_helper.py url notebooklm_blueprint

# Open the primary context in your browser
python scripts/knowledge_base_helper.py open notebooklm_primary

# View the context file for AI agents
python scripts/knowledge_base_helper.py context
```

## Integration with AI Agents

This script is particularly useful for AI agents (Gemini, Jules, etc.) that need to:
1. Access NotebookLM context before starting work
2. Retrieve specific resource URLs programmatically
3. Read the AI agent directives from the context file

AI agents can use this script to ensure they have the latest resource URLs and understand the project context before making changes.

## Related Documentation

- [KNOWLEDGE_BASE_INTEGRATION.md](../docs/KNOWLEDGE_BASE_INTEGRATION.md) - Comprehensive integration guide
- [AGENTS.md](../AGENTS.md) - Agent configuration and guidelines
- [USER_NOTES.md](../docs/USER_NOTES.md) - User notes and external links
