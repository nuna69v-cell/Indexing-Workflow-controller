# 🏢 3-6-9 Universal Organization Guidelines
Centralized guidelines for the 3-6-9 Universal trading organization.

## 📓 Essential Knowledge Base
- **NotebookLM URL**: [https://notebooklm.google.com/notebook/e8f4c29d-9aec-4d5f-8f51-2ca168687616](https://notebooklm.google.com/notebook/e8f4c29d-9aec-4d5f-8f51-2ca168687616)
- **Mandatory Action**: AI agents **MUST ALWAYS** read the contents of this notebook before starting work.

## 🛠️ Strategic Focus
- **Trading**: MetaTrader 5 (MQL5), Exness Integration.
- **Infrastructure**: VPS Automation, Cloud Builds.
- **Intelligence**: AI/ML Strategy Execution.

## 💬 Communication
- **Larksuite Organization**: 3-6-9 Universal
- **Invite Link**: [Join via Larksuite](https://tjp5kb6hm0d8.jp.larksuite.com/invite/9a56hc8aW9jp1?join=1&team_name=3-6-9+Universal)
- **8-digit Invite Code**: MJYVKVYQ
