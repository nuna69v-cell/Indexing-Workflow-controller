# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://genx-fx.com",
    ],
)
