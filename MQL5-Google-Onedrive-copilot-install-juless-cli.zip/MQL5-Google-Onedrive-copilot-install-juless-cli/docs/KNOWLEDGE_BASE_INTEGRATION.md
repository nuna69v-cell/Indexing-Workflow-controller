# Knowledge Base Integration Guide

This guide explains how to access and integrate with the project's knowledge bases: NotebookLM notebooks and OneDrive Blueprint notes.

## 📓 NotebookLM Notebooks

The project uses multiple NotebookLM notebooks for different purposes:

### Primary Context Notebook
- **URL**: [https://notebooklm.google.com/notebook/e8f4c29d-9aec-4d5f-8f51-2ca168687616](https://notebooklm.google.com/notebook/e8f4c29d-9aec-4d5f-8f51-2ca168687616)
- **Purpose**: Main repository context, documentation, and general project information
- **Access**: Read and Write
- **Usage**: AI agents should read this notebook before starting work to understand the project structure and guidelines

### Blueprint & Strategy Notebook
- **URL**: [https://notebooklm.google.com/notebook/da5f7773-bb49-40d5-975c-2a30fd6b37c3](https://notebooklm.google.com/notebook/da5f7773-bb49-40d5-975c-2a30fd6b37c3)
- **Purpose**: Trading strategies, blueprints, and implementation details
- **Access**: Read and Write
- **Usage**: Contains specific trading logic, Smart Money Concepts (SMC) strategies, and EA blueprints

### Legacy Context Notebook (Archive)
- **URL**: [https://notebooklm.google.com/notebook/0e4dfc9b-d57d-4cfc-812d-905d37d67402](https://notebooklm.google.com/notebook/0e4dfc9b-d57d-4cfc-812d-905d37d67402)
- **Purpose**: Historical context and archived notes
- **Access**: Read only (for reference)
- **Usage**: Reference material for understanding project evolution

## 📁 OneDrive Blueprint Notes

### Quick Notes - Blueprint
- **URL**: [View Blueprint](https://onedrive.live.com/view.aspx?resid=8F247B1B46E82304%21s47a25b152cbc4de0986115d88145a225&id=documents&wd=target%28Quick%20Notes.one%7C8BA711F8-2F20-4E7B-80E6-8A8AE35E44EE%2F%F0%9F%9F%A6Blueprint%7C537850C8-5311-4245-998C-DF5B039E5053%2F%29&wdpartid={2A7121B3-322E-660B-0CE6-D3E30D3240A7}{1}&wdsectionfileid=8F247B1B46E82304!s1989476304ab43a4b1dec048cc4fe5ec)
- **Purpose**: Quick reference notes, trading blueprints, and strategy sketches
- **Format**: OneNote document
- **Access**: View and Edit (with OneDrive authentication)
- **Content**: Trading setups, visual diagrams, and quick reference materials

## 🔄 Automatic Synchronization

### OneDrive Sync (GitHub Actions)
The repository includes automatic OneDrive synchronization via GitHub Actions:

**Workflow**: `.github/workflows/onedrive-sync.yml`

**Features**:
- Syncs `mt5/MQL5` directory to OneDrive on every push to main
- Uses `rclone` for reliable file synchronization
- Configurable remote and path via GitHub Secrets

**Required Secrets**:
- `RCLONE_CONFIG_B64`: Base64-encoded rclone configuration file

**Optional Secrets**:
- `ONEDRIVE_REMOTE`: Remote name in rclone.conf (default: `onedrive`)
- `ONEDRIVE_PATH`: Destination path (default: `Apps/MT5/MQL5`)

**Setup**:
1. Configure rclone locally with OneDrive:
   ```bash
   rclone config
   ```
2. Encode your rclone config:
   ```bash
   base64 -w0 ~/.config/rclone/rclone.conf
   ```
3. Add the encoded config to GitHub Secrets as `RCLONE_CONFIG_B64`

## 🤖 AI Agent Integration

### For AI Agents (Gemini, Jules, Claude, etc.)

When working with this repository, AI agents should:

1. **Read the Primary Context Notebook** first to understand:
   - Repository structure
   - Key files and directories
   - Development guidelines
   - Testing procedures

2. **Read the Blueprint & Strategy Notebook** for:
   - Trading strategy details
   - Smart Money Concepts (SMC) implementation
   - Risk management parameters
   - Entry/exit logic

3. **Reference OneDrive Blueprint Notes** for:
   - Visual diagrams and charts
   - Quick reference materials
   - Strategy sketches

### Integration Workflow

```mermaid
graph TD
    A[Start Task] --> B[Read Primary NotebookLM]
    B --> C[Read Blueprint NotebookLM]
    C --> D[Reference OneDrive Notes]
    D --> E[Make Code Changes]
    E --> F[Update Documentation]
    F --> G[Sync to OneDrive]
```

### Context Files

The repository includes helper files for AI agents:

- `AGENTS.md`: Quick reference for agents
- `docs/NOTEBOOK_LM_CONTEXT.txt`: Context file with all URLs and instructions
- `docs/USER_NOTES.md`: User-specific notes and external links

## 🔐 Access Control

### NotebookLM
- Requires Google account authentication
- Shared access can be configured per notebook
- Read/Write permissions managed by notebook owner

### OneDrive
- Requires Microsoft account authentication
- Access controlled via OneDrive sharing settings
- View/Edit permissions managed by file owner

### GitHub Secrets
- Managed via repository settings
- Required for automated synchronization
- Only accessible to authorized GitHub Actions

## 📝 Best Practices

1. **Always Read Before Writing**: Agents should read all relevant notebooks before making changes
2. **Keep Context Updated**: Update notebooks when making significant changes to the repository
3. **Document External Links**: Add new external resources to `docs/USER_NOTES.md`
4. **Sync Regularly**: Ensure OneDrive sync is working by checking workflow logs
5. **Version Control**: Document major strategy changes in both NotebookLM and repository

## 🔧 Troubleshooting

### OneDrive Sync Issues
- Check GitHub Actions logs: `.github/workflows/onedrive-sync.yml`
- Verify `RCLONE_CONFIG_B64` secret is set correctly
- Test rclone configuration locally before encoding

### NotebookLM Access Issues
- Ensure proper Google account authentication
- Verify notebook sharing permissions
- Check if notebook URLs are still valid

### Integration Failures
- Review AI agent logs for specific errors
- Verify all URLs are accessible
- Check network connectivity and firewall rules

## 📚 Related Documentation

- [AGENTS.md](../AGENTS.md) - Agent configuration and guidelines
- [USER_NOTES.md](USER_NOTES.md) - User notes and external links
- [NOTEBOOK_LM_CONTEXT.txt](NOTEBOOK_LM_CONTEXT.txt) - Context file for AI agents
- [README.md](../README.md) - Main project documentation

## 🆘 Support

For issues or questions:
- Create an issue in the GitHub repository
- Check the WhatsApp Agent community: [Join here](https://chat.whatsapp.com/DYemXrBnMD63K55bjUMKYF)
- Email: `Lengkundee01.org@domain.com`
