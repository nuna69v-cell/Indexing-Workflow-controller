import git from 'isomorphic-git';
import http from 'isomorphic-git/http/node';
import fs from 'fs';
import path from 'path';

const dir = process.cwd();
const token = 'REDACTED';
const repoUrl = 'https://github.com/nuna69v-cell/Desktop-device-770099.git';

async function pushDevice() {
  try {
    console.log('Initializing repository...');
    if (fs.existsSync(path.join(dir, '.git'))) {
        fs.rmSync(path.join(dir, '.git'), { recursive: true, force: true });
    }
    await git.init({ fs, dir });

    console.log('Adding files...');
    const files = await fs.promises.readdir(dir);
    for (const file of files) {
      if (file === '.git' || file === 'node_modules' || file === 'push_log.txt') continue;
      await git.add({ fs, dir, filepath: file });
    }

    console.log('Committing...');
    await git.commit({
      fs,
      dir,
      author: {
        name: 'nuna69v-cell',
        email: 'nuna69v@gmail.com',
      },
      message: 'Initial commit for Desktop Device 770099',
    });

    console.log('Creating work branch...');
    await git.branch({ fs, dir, ref: 'work', checkout: true });

    console.log(`Pushing to ${repoUrl}...`);
    const pushResult = await git.push({
      fs,
      http,
      dir,
      remote: 'origin',
      ref: 'work',
      url: repoUrl,
      force: true,
      onAuth: () => ({ username: token }),
    });
    console.log(`Push to ${repoUrl} successful:`, pushResult.ok);

  } catch (err) {
    console.error('Error during push:', err);
    process.exit(1);
  }
}

pushDevice();
