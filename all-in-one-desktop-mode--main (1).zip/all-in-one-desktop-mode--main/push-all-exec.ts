import git from 'isomorphic-git';
import http from 'isomorphic-git/http/node';
import fs from 'fs';
import path from 'path';

const dir = process.cwd();
const token = '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';
const repos = [
  'https://github.com/nuna69v-cell/.github.git',
  'https://github.com/nuna69v-cell/A6..9V-GenX_FX.main.git',
  'https://github.com/nuna69v-cell/agency-agents.git',
  'https://github.com/nuna69v-cell/agent-skills.git',
  'https://github.com/nuna69v-cell/AI-model.git',
  'https://github.com/nuna69v-cell/aif_tutorial.git',
  'https://github.com/nuna69v-cell/AJBrownThesisIsotherms.git',
  'https://github.com/nuna69v-cell/all-in-one-desktop-mode-.git',
  'https://github.com/nuna69v-cell/androidx.git',
  'https://github.com/nuna69v-cell/android_kernel_microsoft_WSA.git',
  'https://github.com/nuna69v-cell/ansible-role-api-bridge.git',
  'https://github.com/nuna69v-cell/api-cli.git',
  'https://github.com/nuna69v-cell/Autonomous-trading-Exness.git',
  'https://github.com/nuna69v-cell/awesome.git',
  'https://github.com/nuna69v-cell/aws-ec2-t-unlimited.git',
  'https://github.com/nuna69v-cell/circleci-docs.git',
  'https://github.com/nuna69v-cell/Complete-backend-.git',
  'https://github.com/nuna69v-cell/Core.git',
  'https://github.com/nuna69v-cell/cursor.git',
  'https://github.com/nuna69v-cell/Database-collaborate-components.git',
  'https://github.com/nuna69v-cell/Demo-driver-Bridge.git',
  'https://github.com/nuna69v-cell/demo-repository.git',
  'https://github.com/nuna69v-cell/demy-landing.git',
  'https://github.com/nuna69v-cell/Desktop-device-770099.git',
  'https://github.com/nuna69v-cell/Dev-handbooks.git',
  'https://github.com/nuna69v-cell/docker.git',
  'https://github.com/nuna69v-cell/docker-images.git',
  'https://github.com/nuna69v-cell/docker.com.git',
  'https://github.com/nuna69v-cell/Domain.git',
  'https://github.com/nuna69v-cell/drive-mobile.git',
  'https://github.com/nuna69v-cell/EA.git',
  'https://github.com/nuna69v-cell/edgetunnel.git',
  'https://github.com/nuna69v-cell/eXPerienceBar.git',
  'https://github.com/nuna69v-cell/eXPeriencefox.git',
  'https://github.com/nuna69v-cell/fontforge.github.io.git',
  'https://github.com/nuna69v-cell/FXPRO-broker.git',
  'https://github.com/nuna69v-cell/gitbook.git',
  'https://github.com/nuna69v-cell/GitHub-document.git',
  'https://github.com/nuna69v-cell/github-mcp-server.git',
  'https://github.com/nuna69v-cell/hardhat-starter-kit.git',
  'https://github.com/nuna69v-cell/HEARTBEAT.git',
  'https://github.com/nuna69v-cell/hosts-farm.git',
  'https://github.com/nuna69v-cell/Indexing-Workflow-controller.git',
  'https://github.com/nuna69v-cell/isodb-library.git',
  'https://github.com/nuna69v-cell/isodbtools.git',
  'https://github.com/nuna69v-cell/isotherm-digitizer-panel.git',
  'https://github.com/nuna69v-cell/jet.git',
  'https://github.com/nuna69v-cell/JETSCAPE.git',
  'https://github.com/nuna69v-cell/jules-action.git',
  'https://github.com/nuna69v-cell/jules-awesome-list.git',
  'https://github.com/nuna69v-cell/jules-sdk.git',
  'https://github.com/nuna69v-cell/Launcher-.git',
  'https://github.com/nuna69v-cell/linux_kernel_microsoft_wsa.git',
  'https://github.com/nuna69v-cell/Memory.git',
  'https://github.com/nuna69v-cell/Microsoft-Teams-Samples.git',
  'https://github.com/nuna69v-cell/MinecraftForge.git',
  'https://github.com/nuna69v-cell/ML.git',
  'https://github.com/nuna69v-cell/MQL5-Google-Onedrive.git',
  'https://github.com/nuna69v-cell/my-driver-projects.git',
  'https://github.com/nuna69v-cell/NIST-Cybersecurity-Framework-R1-1.github.io.git',
  'https://github.com/nuna69v-cell/nist-data-mirror.git',
  'https://github.com/nuna69v-cell/numpy.git',
  'https://github.com/nuna69v-cell/Octopus-station.git',
  'https://github.com/nuna69v-cell/office-js.git',
  'https://github.com/nuna69v-cell/openscap.git',
  'https://github.com/nuna69v-cell/pandas.git',
  'https://github.com/nuna69v-cell/parrot-iso-build.git',
  'https://github.com/nuna69v-cell/render-mcp-server.git',
  'https://github.com/nuna69v-cell/sdk.git',
  'https://github.com/nuna69v-cell/Security-manager-directory.git',
  'https://github.com/nuna69v-cell/skills-hello-github-actions.git',
  'https://github.com/nuna69v-cell/termius-cli.git',
  'https://github.com/nuna69v-cell/termux-packages.git',
  'https://github.com/nuna69v-cell/ToolJet.git',
  'https://github.com/nuna69v-cell/Trading-engine.git',
  'https://github.com/nuna69v-cell/Warp.git',
  'https://github.com/nuna69v-cell/Windows11-Bypass.git',
  'https://github.com/nuna69v-cell/windup.git',
];

async function pushAll() {
  try {
    console.log('Initializing repository...');
    if (fs.existsSync(path.join(dir, '.git'))) {
        fs.rmSync(path.join(dir, '.git'), { recursive: true, force: true });
    }
    await git.init({ fs, dir });

    console.log('Adding files...');
    const files = await fs.promises.readdir(dir);
    for (const file of files) {
      if (file === '.git' || file === 'node_modules') continue;
      await git.add({ fs, dir, filepath: file });
    }

    console.log('Committing...');
    await git.commit({
      fs,
      dir,
      author: {
        name: 'nuna69v-cell',
        email: 'nuna69v@gmail.com',
      },
      message: 'Sync: Desktop Device 770099 - Bridge Connection',
    });

    console.log('Creating main branch...');
    await git.branch({ fs, dir, ref: 'main', checkout: true });

    for (const repoUrl of repos) {
      console.log(`Pushing to ${repoUrl}...`);
      try {
        const pushResult = await git.push({
          fs,
          http,
          dir,
          remote: 'origin',
          ref: 'main',
          url: repoUrl,
          force: true,
          onAuth: () => ({ username: token }),
        });
        console.log(`Push to ${repoUrl} successful:`, pushResult.ok);
      } catch (e) {
        console.error(`Failed to push to ${repoUrl}:`, e.message);
      }
    }

  } catch (err) {
    console.error('Error during push all:', err);
    process.exit(1);
  }
}

pushAll();
