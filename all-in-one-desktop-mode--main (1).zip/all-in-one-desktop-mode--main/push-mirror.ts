import git from 'isomorphic-git';
import http from 'isomorphic-git/http/node';
import fs from 'fs';
import path from 'path';

const dir = process.cwd();
const token = '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';
const mirrorRepoUrl = 'https://github.com/nuna69v-cell/MQL5-Google-Onedrive.git';

async function pushMirror() {
  try {
    console.log('Initializing repository for mirror...');
    if (fs.existsSync(path.join(dir, '.git'))) {
        // Clean up existing git if any
        fs.rmSync(path.join(dir, '.git'), { recursive: true, force: true });
    }
    await git.init({ fs, dir });

    console.log('Adding files...');
    const files = await fs.promises.readdir(dir);
    for (const file of files) {
      if (file === '.git' || file === 'node_modules') continue;
      await git.add({ fs, dir, filepath: file });
    }

    console.log('Committing...');
    await git.commit({
      fs,
      dir,
      author: {
        name: 'nuna69v-cell',
        email: 'nuna69v@gmail.com',
      },
      message: 'Mirror push: GenX FX Dashboard',
    });

    console.log('Creating main branch...');
    await git.branch({ fs, dir, ref: 'main', checkout: true });

    console.log('Pushing to mirror repo...');
    const pushResult = await git.push({
      fs,
      http,
      dir,
      remote: 'origin',
      ref: 'main',
      url: mirrorRepoUrl,
      force: true,
      onAuth: () => ({ username: token }),
    });

    console.log('Mirror push successful:', pushResult);
  } catch (err) {
    console.error('Error during mirror push:', err);
    process.exit(1);
  }
}

pushMirror();
