#!/bin/bash
# setup_script.sh

echo "=========================================================="
echo " GenX FX & My Drive Projects Setup Script "
echo "=========================================================="

# Create a project directory
PROJECT_DIR="C:/my_drive_projects/genx_workspace"
mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR" || return

echo "Creating .env file from Jules memory..."
cat << 'ENVEOF' > .env
# ===============================================
# GENX FX TRADING PLATFORM CONFIGURATION
# ===============================================
PROJECT_NAME=GenX FX

# MT5 Trading Account Details
MT5_ACCOUNT_ID=514832489
MT5_SERVER=MT5 Standard
MT5_PASSWORD=Leng3A69V@Una
MT5_TERMINAL_PATH=C:\Program Files\MetaTrader 5\terminal64.exe

# ===============================================
# API KEYS & TOKENS
# ===============================================

# Telegram Bot
TELEGRAM_BOT_HANDLE=t.me/GenX_FX_bot
TELEGRAM_BOT_TOKEN=8260686409:AAHEcrZxhDve9vE1QR49ngcCmvOf_Q9NYHg

# Bybit Exchange
BYBIT_API_KEY=eqnyZoVdWnmyMHtiYFp8pRYb44UMTYYh5WE76dx4DSXVFIVKLNIiwht3Ksus4VNMo
BYBIT_SECRET_KEY=EHVCCRXbo6DntpdQU1Ogqo2wkEZXGKfejk9aec7VwYDy&J8vUqqCQPTKDIOP2

# AMP Token
AMP_TOKEN=sgamp_user_01K7JX36MZ2EA752XMB3924BS3_dc125ec2c40e936e2722299afd114bc2d6237f5ab8d5f5cb10b542c9729669bf

# Jules AI API
JULES_API_KEY=AQ.Ab8RN6IF6AG1nGOpg0qc8fivBH_uEWWS2oS9bdNUZ-qfihfI3A
# Alternative Jules API Keys:
# JULES_API_KEY=AQ.Ab8RN6KlUp0GO6d0b-Y0d3WuZhS0oBTsfGy_91HNwKeBODSLTA
# JULES_API_KEY=AQ.Ab8RN6K3J3t0Rc_wsndYjvM0fHmTgzfPBPsWdfOmc9fL6mIGEA
# JULES_API_KEY=AQ.Ab8RN6IKx9oDSm6lWW3Yu06oJOrMCf_vaZOGntzpgumCQcRL0Q

# GitHub
GITHUB_TOKEN=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

# Development Tools
CURSOR_JET_BRAIN_KEY=key_33ea9dc361652d24066c817c1c9654ffb316982a7ba09425454df71ec99da499

# Docker Credentials
DOCKER_USERNAME=lengkundee01@gmail.com
DOCKER_PASSWORD=Leng3A69V[@Una]
DOCKER_PAT=dckr_pat_FMob4Pqlvj-kZ1UeeLTkHAmZ210

# Dropbox
DROPBOX_API=JXNXIHBKFYK4MJ6TXKJHKFK45U

# Render
RENDER_API_KEY=rnd_B1HW7x2ay1nwhPhBafgHW9w4ikIb

# Gemini
GEMINI_API=AIzaSyCRfsuY4GZNlCNt6i_8rMLzRDZ0SjNW_Bg

# ===============================================
# FILE PATH/SETUP (for GenX FX project)
# ===============================================
BASE_DRIVE_PATH="C:"
ENVEOF

echo "Cloning repositories from Mouy-leng172..."

REPOS=(
  "https://github.com/Mouy-leng172/-Java.git"
  "https://github.com/Mouy-leng172/.Net-sdk.git"
  "https://github.com/Mouy-leng172/A6-9V.git"
  "https://github.com/Mouy-leng172/A6..9V-GenX_FX.main.git"
  "https://github.com/Mouy-leng172/actions-template-sync.git"
  "https://github.com/Mouy-leng172/agent-skills.git"
  "https://github.com/Mouy-leng172/agents.git"
  "https://github.com/Mouy-leng172/amphtml.git"
  "https://github.com/Mouy-leng172/Autonomous-trading-Exness.git"
  "https://github.com/Mouy-leng172/awesome.git"
  "https://github.com/Mouy-leng172/aws-proton-cloudformation-sample-templates.git"
  "https://github.com/Mouy-leng172/bolt.new.git"
  "https://github.com/Mouy-leng172/chrome-devtools-mcp.git"
  "https://github.com/Mouy-leng172/circleci-docs.git"
  "https://github.com/Mouy-leng172/cli.git"
  "https://github.com/Mouy-leng172/Client.git"
  "https://github.com/Mouy-leng172/cloudeye-exporter.git"
  "https://github.com/Mouy-leng172/codecov-action.git"
  "https://github.com/Mouy-leng172/container.git"
  "https://github.com/Mouy-leng172/core.git"
  "https://github.com/Mouy-leng172/cpuinfo.git"
  "https://github.com/Mouy-leng172/data.git"
  "https://github.com/Mouy-leng172/desktop.git"
  "https://github.com/Mouy-leng172/docs.git"
  "https://github.com/Mouy-leng172/domain-controller.git"
  "https://github.com/Mouy-leng172/EdgeML.git"
  "https://github.com/Mouy-leng172/EzvizSDK-Android.git"
  "https://github.com/Mouy-leng172/firefox.git"
  "https://github.com/Mouy-leng172/FirefoxReality.git"
  "https://github.com/Mouy-leng172/generative-ai.git"
)

for REPO in "${REPOS[@]}"; do
  echo "Cloning $REPO..."
  git clone "$REPO" || echo "Failed to clone $REPO. Make sure your GitHub token is valid and you have access."
done

echo "=========================================================="
echo " Setup Complete! "
echo " Workspace located at: $PROJECT_DIR "
echo " To automate deployment, review the downloaded projects "
echo " and link them to your main branch. "
echo "=========================================================="
