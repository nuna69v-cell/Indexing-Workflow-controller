import sys
import os

try:
    with open('A6..9V-GenX_FX.main/.env', 'r') as f:
        env_content = f.read()
        if "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" in env_content:
            print("Env file successfully created with the new token")
            sys.exit(0)
        else:
            print("Token missing from .env")
            sys.exit(1)
except Exception as e:
    print(f"Failed to read .env: {e}")
    sys.exit(1)
