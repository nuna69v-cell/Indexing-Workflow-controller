#!/usr/bin/env python3
"""
Knowledge Base Access Helper
Provides easy access to NotebookLM and OneDrive Blueprint resources.
"""

import os
import sys
from pathlib import Path

# Get repository root
REPO_ROOT = Path(__file__).resolve().parents[1]
DOCS_DIR = REPO_ROOT / "docs"

# Resource URLs
RESOURCES = {
    "notebooklm_primary": {
        "name": "NotebookLM (Primary Context)",
        "url": "https://notebooklm.google.com/notebook/e8f4c29d-9aec-4d5f-8f51-2ca168687616",
        "description": "Main repository context, documentation, and general project information",
        "access": "Read and Write"
    },
    "notebooklm_blueprint": {
        "name": "NotebookLM (Blueprint & Strategy)",
        "url": "https://notebooklm.google.com/notebook/da5f7773-bb49-40d5-975c-2a30fd6b37c3",
        "description": "Trading strategies, blueprints, and implementation details",
        "access": "Read and Write"
    },
    "notebooklm_legacy": {
        "name": "NotebookLM (Legacy Archive)",
        "url": "https://notebooklm.google.com/notebook/0e4dfc9b-d57d-4cfc-812d-905d37d67402",
        "description": "Historical context and archived notes",
        "access": "Read only"
    },
    "onedrive_blueprint": {
        "name": "OneDrive Blueprint Notes",
        "url": "https://onedrive.live.com/view.aspx?resid=8F247B1B46E82304%21s47a25b152cbc4de0986115d88145a225&id=documents&wd=target%28Quick%20Notes.one%7C8BA711F8-2F20-4E7B-80E6-8A8AE35E44EE%2F%F0%9F%9F%A6Blueprint%7C537850C8-5311-4245-998C-DF5B039E5053%2F%29&wdpartid={2A7121B3-322E-660B-0CE6-D3E30D3240A7}{1}&wdsectionfileid=8F247B1B46E82304!s1989476304ab43a4b1dec048cc4fe5ec",
        "description": "Quick reference notes, trading blueprints, and strategy sketches",
        "access": "View and Edit (with OneDrive authentication)"
    }
}

def print_header(text):
    """Print a formatted header."""
    print(f"\n{'=' * 80}")
    print(f"  {text}")
    print(f"{'=' * 80}\n")

def list_resources():
    """List all available knowledge base resources."""
    print_header("📚 Knowledge Base Resources")
    
    for key, resource in RESOURCES.items():
        print(f"📌 {resource['name']}")
        print(f"   URL: {resource['url']}")
        print(f"   Description: {resource['description']}")
        print(f"   Access: {resource['access']}")
        print()

def get_resource_url(resource_key):
    """Get URL for a specific resource."""
    if resource_key in RESOURCES:
        return RESOURCES[resource_key]["url"]
    else:
        print(f"❌ Resource '{resource_key}' not found.")
        print(f"Available resources: {', '.join(RESOURCES.keys())}")
        return None

def read_context_file():
    """Read and display the NOTEBOOK_LM_CONTEXT.txt file."""
    context_file = DOCS_DIR / "NOTEBOOK_LM_CONTEXT.txt"
    
    if not context_file.exists():
        print(f"❌ Context file not found: {context_file}")
        return
    
    print_header("📄 NotebookLM Context File")
    with open(context_file, 'r') as f:
        print(f.read())

def open_resource(resource_key):
    """Attempt to open a resource in the default browser."""
    url = get_resource_url(resource_key)
    if url:
        try:
            import webbrowser
            print(f"🌐 Opening {RESOURCES[resource_key]['name']}...")
            webbrowser.open(url)
            print(f"✅ Opened in your default browser")
        except Exception as e:
            print(f"❌ Could not open browser: {e}")
            print(f"Please manually open: {url}")

def print_usage():
    """Print usage information."""
    print("""
Usage: python knowledge_base_helper.py [command] [resource]

Commands:
    list                - List all available resources
    url [resource]      - Get URL for a specific resource
    open [resource]     - Open resource in default browser
    context             - Display NOTEBOOK_LM_CONTEXT.txt
    help                - Show this help message

Resources:
    notebooklm_primary   - Primary NotebookLM context
    notebooklm_blueprint - Blueprint & Strategy NotebookLM
    notebooklm_legacy    - Legacy Archive NotebookLM
    onedrive_blueprint   - OneDrive Blueprint Notes

Examples:
    python knowledge_base_helper.py list
    python knowledge_base_helper.py url notebooklm_primary
    python knowledge_base_helper.py open notebooklm_blueprint
    python knowledge_base_helper.py context
""")

def main():
    """Main entry point."""
    if len(sys.argv) < 2:
        print_usage()
        return
    
    command = sys.argv[1].lower()
    
    if command == "list":
        list_resources()
    elif command == "url":
        if len(sys.argv) < 3:
            print("❌ Please specify a resource key")
            print(f"Available: {', '.join(RESOURCES.keys())}")
            return
        url = get_resource_url(sys.argv[2])
        if url:
            print(f"URL: {url}")
    elif command == "open":
        if len(sys.argv) < 3:
            print("❌ Please specify a resource key")
            print(f"Available: {', '.join(RESOURCES.keys())}")
            return
        open_resource(sys.argv[2])
    elif command == "context":
        read_context_file()
    elif command == "help":
        print_usage()
    else:
        print(f"❌ Unknown command: {command}")
        print_usage()

if __name__ == "__main__":
    main()
