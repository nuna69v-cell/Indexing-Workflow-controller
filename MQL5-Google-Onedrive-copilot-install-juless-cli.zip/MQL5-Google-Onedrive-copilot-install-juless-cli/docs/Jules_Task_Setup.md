# Jules Task Setup Guide

## Task ID: 11566195936388909103

This document describes how to pull and setup the Jules task with ID `11566195936388909103`.

## Prerequisites

1. **Jules CLI**: Install the Google Jules CLI tool
   ```bash
   npm install -g @google/jules
   ```

2. **Authentication**: You need to authenticate with your Google account
   ```bash
   jules login
   ```
   This will open a browser window for Google OAuth authentication.

3. **Repository Access**: Ensure your GitHub account is connected to Jules and has access to this repository.

## Pulling the Task

To retrieve the task details and any code changes from Jules:

```bash
# Pull the task by session ID
jules remote pull --session 11566195936388909103
```

This command will:
- Fetch the task description and requirements
- Download any code changes or generated files
- Show the task status and completion details

## Alternative: Using Jules TUI

You can also use the Jules Terminal User Interface for a more interactive experience:

```bash
# Launch the Jules TUI
jules
```

Then navigate to the task using the session ID to view details, logs, and outputs.

## Setup Process

Once you've pulled the task:

1. **Review Task Details**: Check the task description and requirements
2. **Apply Changes**: If the task includes code changes, review and apply them
3. **Test Changes**: Run the repository validation and tests:
   ```bash
   python scripts/ci_validate_repo.py
   python scripts/test_automation.py
   ```
4. **Commit and Push**: Commit any changes following the repository's contribution guidelines

## Troubleshooting

### 403 Error
If you encounter a 403 error:
- Ensure you've run `jules login` and completed authentication
- Verify your GitHub account is linked in Jules settings
- Check that you have access to the repository in both Jules and GitHub

### Task Not Found
If the session/task ID is not found:
- Verify the task ID is correct
- Ensure the task belongs to your account or you have shared access
- Check the task status in the Jules web dashboard

## Additional Resources

- Jules Documentation: https://jules.google/docs/
- Jules CLI Reference: https://jules.google/docs/cli/reference
- Jules Dashboard: https://jules.google/

## Task Context

This setup is part of integrating Google Jules AI coding agent capabilities with the MQL5-Google-OneDrive repository. The task may include:
- Code improvements or refactoring
- New features or functionality
- Bug fixes
- Documentation updates
- Infrastructure or deployment changes

After pulling the task, review the specific requirements and implement them according to the project's standards and guidelines.
