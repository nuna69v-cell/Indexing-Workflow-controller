#!/bin/bash
# Automates setting up GitHub secrets and variables via the gh CLI
# Usage: ./setup-github-secrets.sh <github-repo>
# Example: ./setup-github-secrets.sh nuna69v-cell/Autonomous-trading-Exness

if [ -z "$1" ]; then
    echo "Usage: ./setup-github-secrets.sh <github-repo>"
else
    REPO=$1
    echo "Setting up secrets and variables for $REPO..."

    # A list of secrets to read from the environment or input
    SECRETS=(
        "MT5_ACCOUNT_ID" "MT5_SERVER" "MT5_PASSWORD" "MT5_TERMINAL_PATH"
        "MQL5_LOGIN" "MQL5_PASSWORD" "MQL5_LOGIN_TERMINAL" "MQL5_LOGIN_PASSWORD"
        "TELEGRAM_BOT_HANDLE" "TELEGRAM_BOT_TOKEN"
        "BYBIT_API_KEY" "BYBIT_SECRET_KEY"
        "OKX_API_KEY" "OKX_SECRET_KEY"
        "AMP_TOKEN" "JULES_API_KEY" "GITHUB_TOKEN" "CURSOR_JET_BRAIN_KEY"
        "DOCKER_USERNAME" "DOCKER_PASSWORD" "DOCKER_PAT"
        "RAILWAY_API" "RENDER_API_KEY" "RENDER_OAUTH_CLIENT_ID" "RENDER_OAUTH_CLIENT_SECRET"
        "SUPABASE_URL" "GITLAB_API_TOKEN" "GCP_SCRIPT_ID" "FIREBASE_PROJECT_ID"
        "GEMINI_API" "VPS_API" "DROPBOX_API" "CODE_SANDBOXES_API"
    )

    # Loop through the list, checking if the variable is set in the current environment
    for SECRET in "${SECRETS[@]}"; do
        if [ -n "${!SECRET}" ]; then
            echo "Setting secret $SECRET..."
            gh secret set "$SECRET" --body "${!SECRET}" --repo "$REPO"
        else
            echo "Warning: $SECRET is not set in the current environment. Skipping."
        fi
    done

    echo "Done."
fi
